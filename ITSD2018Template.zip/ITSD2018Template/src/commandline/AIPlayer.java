package commandline;


public class AIPlayer extends Player{
	
}
